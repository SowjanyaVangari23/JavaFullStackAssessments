package com.insight;

public class Arith {

	public Integer add(int i, int j) {
		// TODO Auto-generated method stub
		return i+j;
	}

}
