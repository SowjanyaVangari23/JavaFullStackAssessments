package com.insight;

public class Calculator {
	public boolean isGreaterThan(int a, int b) {
		return a>b;
	}
	public boolean isLessThan(int a, int b) {
		return a<b;
	}
	public String isEmpty(String s) {
		return s;
	}

}
