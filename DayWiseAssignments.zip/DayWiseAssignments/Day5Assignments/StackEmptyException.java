package Exceptionsdemo;

public class StackEmptyException extends Exception{
	StackEmptyException(String msg){
		super(msg);
	}

}
