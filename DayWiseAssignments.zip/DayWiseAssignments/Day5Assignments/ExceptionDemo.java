package Exceptionsdemo;

public class ExceptionDemo {

	public static void main(String[] args) {
		int a=10;
		int b=0;
		int c;
		int x[]= {1,2,3};
//		try {
//			c=a/b;
//			System.out.println(x[5]);
//			
//			
//			
//		}
//		catch(ArithmeticException e){
//			System.out.println(e);
//			
//		}
//		catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println(e);
//		}
		
		//nested try catch
		
		
		
		
		
		
		
	
//		try {
//			System.out.println(x[5]);
//			
//		}
//		catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println(e);
//		}
//		
//		
//		
//		
//		try {
//			c=a/b;
//			
//		}
//		catch(ArithmeticException e){
//			System.out.println(e);
//			
//		}
//		
//		System.out.println("Thanks");

	}

}
