package Exceptionsdemo;

public class StackFullException extends Exception {
	StackFullException(String msg){
	
	super(msg);
	}
	

}
