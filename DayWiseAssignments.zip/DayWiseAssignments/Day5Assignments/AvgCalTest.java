package Exceptionsdemo;

public class AvgCalTest {

	public static void main(String[] args) {
		AvgCalculator ac=new AvgCalculator();
		System.out.println(ac.calAverage(7)); 

	}

}

