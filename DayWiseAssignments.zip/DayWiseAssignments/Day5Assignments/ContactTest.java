package Exceptionsdemo;

public class ContactTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
