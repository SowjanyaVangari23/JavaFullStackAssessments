package Exceptionsdemo;

public class NullPointerException extends Exception {
	NullPointerException(String msg){
		super(msg);
	}
	

}
