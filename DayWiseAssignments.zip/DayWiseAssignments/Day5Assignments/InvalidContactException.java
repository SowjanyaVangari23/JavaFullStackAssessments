package Exceptionsdemo;

public class InvalidContactException extends Exception{
	InvalidContactException(String msg){
		super(msg);
	}
	

}
