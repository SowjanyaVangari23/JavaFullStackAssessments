package Exceptionsdemo;

public class IllegalArgumentException extends Exception {
	 IllegalArgumentException(String msg){
		 super(msg);
	 }

}
