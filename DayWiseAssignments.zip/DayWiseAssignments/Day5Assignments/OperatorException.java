package Exceptionsdemo;

public class OperatorException extends Exception {
	OperatorException(String msg){
		super(msg);
	}
	
	
	

}
