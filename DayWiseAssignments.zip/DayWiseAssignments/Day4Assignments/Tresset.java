//package Day4Ass;
//
//import java.util.HashSet;
//import java.util.LinkedHashSet;
//import java.util.LinkedList;
//import java.util.TreeSet;
//
//public class Tresset {
//
//	private static final LinkedHashSet<Object> Integer = null;
//
//	public static void main(String[] args) {
//
////		TreeSet <Integer> ts=new TreeSet<>();
////		ts.add(1);
////		ts.add(12);
////		ts.add(5);
////		System.out.println(ts);
////		ts.remove(5);
////		System.out.println(ts);
////		ts.clear();
////		
////		System.out.println(ts);
//		
////		HashSet<Integer> hs=new HashSet<>();
////		
////		hs.add(1);
////		hs.add(1);
////		hs.add(2);
////		hs.add(14);
////		hs.add(3);
////		System.out.println(hs);
////		hs.remove(14);
////		System.out.println(hs);
////		
//		
////		LinkedList<Integer>li=new LinkedList<>();
////		li.add(3);
////		li.addFirst(3);
////		li.addFirst(4);
////		li.addLast(9);;
////		System.out.println(li);
////		
////		System.out.println(li.get(3));
////		
////
////	}
//		
//		LinkedHashSet<String> set = new LinkedHashSet<>();
//		
//		
//		
//		
//
//}
