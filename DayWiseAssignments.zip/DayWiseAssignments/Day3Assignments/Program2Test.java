package CoreAssignments;

public class Program2Test {

	public static void main(String[] args) {
		Program2 p2=new Program2();
		int[] arr = {4, 8, 6, 1, 9, 4};
        System.out.println(p2.findMaxDistance(arr, arr.length));

	}

}
