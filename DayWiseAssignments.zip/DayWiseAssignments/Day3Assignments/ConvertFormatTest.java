package CoreAssignments;

public class ConvertFormatTest {
	

	public static void main(String[] args) {
		
		String input = "555-666-1234";
		 String result = ConverFormat.convertFormat(input);
	        System.out.println(result); 

	}

}
