package CoreAssignments;

public class Program4Test {

	public static void main(String[] args) {
		Program4 p=new Program4();
		
		String inputStr = "Rabbit";
		char c = '-';
		  String finalString = p.reshape(inputStr, c);
	        System.out.println(finalString);

	}

}
