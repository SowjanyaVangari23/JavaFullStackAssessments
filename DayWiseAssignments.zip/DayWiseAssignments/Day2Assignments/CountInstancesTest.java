package Day2Assignment;

public class CountInstancesTest {

	public static void main(String[] args) {
		CountInstances c=new CountInstances();
		CountInstances c1=new CountInstances();
		CountInstances c2=new CountInstances();
		
		System.out.println(CountInstances.getCountinst());

	}

}
