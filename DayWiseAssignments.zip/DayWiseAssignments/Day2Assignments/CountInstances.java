package Day2Assignment;

public class CountInstances {
	public static int countinst=0;
	
	public CountInstances() {
		countinst++;
	}
	
	

	public static int getCountinst() {
		return countinst;
	}

	
	
	
	
	
	

}
