package Day2Assignment;

public class Manager  extends Employee{
	
	 @Override
	    public void roles_Responsibilities() {
	        System.out.println("Roles and Responsibilities of Manager:");
	        System.out.println("1. Overseeing team performance.");
	        System.out.println("2. Setting objectives and goals.");
	        System.out.println("3. Ensuring projects are completed on time.");
}
}