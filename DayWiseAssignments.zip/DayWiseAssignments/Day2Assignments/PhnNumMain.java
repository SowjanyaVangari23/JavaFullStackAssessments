package Day2Assignment;

public class PhnNumMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PhoneNum21docx p1=new PhoneNum21docx("910","426","5678");
		PhoneNum21docx p2=new PhoneNum21docx("920","786","8978");
		PhoneNum21docx p3=new PhoneNum21docx("913","566","8278");
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p1.equals(p2));
		System.out.println(p2.equals(p2));
		

	}

}
