package Day2Assignment;

public class CalculatorTest {

	public static void main(String[] args) {
		
		 Calculator c = new CalculatorImp();
		 System.out.println(c.add(2, 3));
		 System.out.println(c.sub(4, 2));
		 System.out.println(c.mul(4, 5));
		 System.out.println(c.div(8, 4));
	}

}

