package Day2Assignment;

public class Main {

	public static void main(String[] args) {
	Manager m=new Manager();
	  m.input(101, "Alice");
	  m.output();
	  m.roles_Responsibilities();
	  
	

	}

}
