package Day2Ass21docx;

public class Cricket extends Game{
	 @Override
	    public void displayInfo() {
	        System.out.println("Cricket is a bat-and-ball game played between two teams of eleven players.");
	    }

}
