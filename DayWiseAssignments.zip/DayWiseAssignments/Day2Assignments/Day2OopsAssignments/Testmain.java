package Day2Ass21docx;

public class Testmain {

	public static void main(String[] args) {
		PassingparamDemo2 p=new PassingparamDemo2();
		p.swap(3, 4);
		int[] arr1= {1,2,3};
		int []arr2= {4,5,6};
		p.swap(arr1, arr2);
		

	}

}
