package Day2Ass21docx;

public class Game {
     public void displayInfo() {
    	 System.out.println("Game method");
    	 
     }

	
}
