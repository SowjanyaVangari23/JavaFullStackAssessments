package Day2Ass21docx;

public class Football extends Game {
    @Override
    public void displayInfo() {
        System.out.println("Football is a team sport played with a spherical ball between two teams of eleven players.");
    }


}
