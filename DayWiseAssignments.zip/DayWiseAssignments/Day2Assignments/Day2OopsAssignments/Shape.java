package Day2Ass21docx;
public abstract class Shape {
    int length;

    public Shape(int length) {
        this.length = length;
    }

    public abstract double calculateArea();
}

