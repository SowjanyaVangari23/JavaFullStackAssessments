package Day2Ass21docx;

public class Tennis extends Game{
	
	 @Override
	    public void displayInfo() {
		 System.out.println("Tennis is a sport played individually or in doubles with a racket and a ball.");
	    }
}
